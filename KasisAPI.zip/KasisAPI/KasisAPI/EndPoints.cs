using System;
using System.Linq;
using KasisAPI.Data;
using KasisAPI.Data.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using SharpGrip.FluentValidation.AutoValidation.Endpoints.Extensions;

using KasisAPI;

public static class Endpoints
{
    public static void AddTopicsApi(this WebApplication app)
    {
        var topicsGroups = app.MapGroup("/api").AddFluentValidationAutoValidation();

        topicsGroups.MapGet("/topics", async (KasisDbContext dbContext) =>
        {
            var topics = await dbContext.Topics.ToListAsync();
            return topics.Select(topic => topic.ToDto());
        });

        topicsGroups.MapPost("/topics", async (CreateOrUpdateTopicDto dto, KasisDbContext dbContext) =>
        {
            var topic = new Topic { Title = dto.Title, Description = dto.Description, CreatedAt = DateTimeOffset.UtcNow };
            dbContext.Topics.Add(topic);
            await dbContext.SaveChangesAsync();

            return Results.Created($"api/topics/{topic.Id}", topic.ToDto());
        });

        topicsGroups.MapGet("/topics/{topicId}", async (int topicId, KasisDbContext dbContext) =>
        {
            var topic = await dbContext.Topics.FindAsync(topicId);
            if (topic == null)
            {
                return Results.NotFound();
            }

            return Results.Ok(topic.ToDto());
        });

        topicsGroups.MapPut("/topics/{topicId}", async (CreateOrUpdateTopicDto dto, int topicId, KasisDbContext dbContext) =>
        {
            var topic = await dbContext.Topics.FindAsync(topicId);
            if (topic == null)
            {
                return Results.NotFound();
            }

            topic.Title = dto.Description;
            topic.Description = dto.Description;
            dbContext.Topics.Update(topic);
            await dbContext.SaveChangesAsync();

            return Results.Ok(topic.ToDto());
        });

        topicsGroups.MapDelete("/topics/{topicId}", async (int topicId, KasisDbContext dbContext) =>
        {
            var topic = await dbContext.Topics.FindAsync(topicId);
            if (topic == null)
            {
                return Results.NotFound();
            }

            dbContext.Topics.Remove(topic);
            await dbContext.SaveChangesAsync();

            return Results.NoContent();
        });
    }

    public static void AddPostsApi(this WebApplication app)
    {
        var postsGroups = app.MapGroup("/api/topics/{topicId}").AddFluentValidationAutoValidation();

        postsGroups.MapGet("/posts", async (int topicId, KasisDbContext dbContext) =>
        {
            var topic = await dbContext.Topics.FindAsync(topicId);
            if (topic == null)
            {
                return Results.NotFound();
            }

            var posts = await dbContext.Posts.Where(post => post.Topic.Id == topicId).ToListAsync();
            return Results.Ok(posts.Select(post => post.ToDto()));
        });

        postsGroups.MapPost("/posts", async (int topicId, CreateOrUpdatePostDto dto, KasisDbContext dbContext) =>
        {
            var topic = await dbContext.Topics.FindAsync(topicId);
            if (topic == null)
            {
                return Results.NotFound();
            }

            var post = new Post { Title = dto.Title, Body = dto.Body, CreatedAt = DateTimeOffset.UtcNow, Topic = topic };
            dbContext.Posts.Add(post);
            await dbContext.SaveChangesAsync();

            return Results.Created($"/api/topics/{topicId}/posts/{post.Id}", post.ToDto());
        });

        postsGroups.MapGet("/posts/{postId}", async (int topicId, int postId, KasisDbContext dbContext) =>
        {
            var posts = dbContext.Posts.Include(post => post.Topic);
            var post = await posts.FirstOrDefaultAsync(post => post.Id == postId && post.Topic.Id == topicId);
            if (post == null)
            {
                return Results.NotFound();
            }

            return Results.Ok(post.ToDto());
        });

        postsGroups.MapPut("/posts/{postId}", async (int topicId, int postId, CreateOrUpdatePostDto dto, KasisDbContext dbContext) =>
        {
            var posts = dbContext.Posts.Include(post => post.Topic);
            var post = await posts.FirstOrDefaultAsync(post => post.Id == postId && post.Topic.Id == topicId);
            if (post == null)
            {
                return Results.NotFound();
            }

            post.Title = dto.Title;
            post.Body = dto.Body;
            dbContext.Posts.Update(post);
            await dbContext.SaveChangesAsync();

            return Results.Ok(post.ToDto());
        });

        postsGroups.MapDelete("/posts/{postId}", async (int topicId, int postId, KasisDbContext dbContext) =>
        {
            var posts = dbContext.Posts.Include(post => post.Topic);
            var post = await posts.FirstOrDefaultAsync(post => post.Id == postId && post.Topic.Id == topicId);
            if (post == null)
            {
                return Results.NotFound();
            }

            dbContext.Posts.Remove(post);
            await dbContext.SaveChangesAsync();

            return Results.NoContent();
        });
    }

    public static void AddCommentsApi(this WebApplication app)
    {
        var commentsGroups = app.MapGroup("/api/topics/{topicId}/posts/{postId}").AddFluentValidationAutoValidation();

        commentsGroups.MapGet("/comments", async (int topicId, int postId, KasisDbContext dbContext) =>
        {
            var posts = dbContext.Posts.Include(post => post.Topic);
            var post = await posts.FirstOrDefaultAsync(post => post.Id == postId && post.Topic.Id == topicId);

            if (post == null || post.Topic.Id != topicId)
            {
                return Results.NotFound();
            }

            var comments = await dbContext.Comments.Where(comment => comment.Post.Id == postId).ToListAsync();
            return Results.Ok(comments.Select(comment => comment.ToDto()));
        });

        commentsGroups.MapPost("/comments", async (int topicId, int postId, CreateOrUpdateCommentDto dto, KasisDbContext dbContext) =>
        {
            var posts = dbContext.Posts.Include(post => post.Topic);
            var post = await posts.FirstOrDefaultAsync(post => post.Id == postId && post.Topic.Id == topicId);

            if (post == null || post.Topic.Id != topicId)
            {
                return Results.NotFound();
            }

            var comment = new Comment
            {
                Content = dto.Content,
                CreatedAt = DateTimeOffset.UtcNow,
                Post = post
            };

            dbContext.Comments.Add(comment);
            await dbContext.SaveChangesAsync();

            return Results.Created($"/api/topics/{topicId}/posts/{postId}/comments/{comment.Id}", comment.ToDto());
        });

        commentsGroups.MapGet("/comments/{commentId}", async (int topicId, int postId, int commentId, KasisDbContext dbContext) =>
        {
            var comment = await dbContext.Comments
                .Include(comment => comment.Post)
                .FirstOrDefaultAsync(comment => comment.Id == commentId && comment.Post.Id == postId && comment.Post.Topic.Id == topicId);

            if (comment == null)
            {
                return Results.NotFound();
            }

            return Results.Ok(comment.ToDto());
        });

        commentsGroups.MapPut("/comments/{commentId}", async (int topicId, int postId, int commentId, CreateOrUpdateCommentDto dto, KasisDbContext dbContext) =>
        {
            var comment = await dbContext.Comments
                .Include(comment => comment.Post)
                .FirstOrDefaultAsync(comment => comment.Id == commentId && comment.Post.Id == postId && comment.Post.Topic.Id == topicId);

            if (comment == null)
            {
                return Results.NotFound();
            }

            comment.Content = dto.Content;
            dbContext.Comments.Update(comment);
            await dbContext.SaveChangesAsync();

            return Results.Ok(comment.ToDto());
        });

        commentsGroups.MapDelete("/comments/{commentId}", async (int topicId, int postId, int commentId, KasisDbContext dbContext) =>
        {
            var comment = await dbContext.Comments
                .Include(comment => comment.Post)
                .FirstOrDefaultAsync(comment => comment.Id == commentId && comment.Post.Id == postId && comment.Post.Topic.Id == topicId);

            if (comment == null)
            {
                return Results.NotFound();
            }

            dbContext.Comments.Remove(comment);
            await dbContext.SaveChangesAsync();

            return Results.NoContent();
        });
    }
}
