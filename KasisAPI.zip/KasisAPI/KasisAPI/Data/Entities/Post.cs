using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace KasisAPI.Data.Entities;

public class Post
{
    public int Id { get; set; }

    [Required]
    public string Title { get; set; }

    [Required]
    public string Body { get; set; }

    [Required]
    public DateTimeOffset CreatedAt { get; set; }

    public bool IsLocked { get; set; }

    public Topic Topic { get; set; }

    public PostDto ToDto()
    {
        return new PostDto(this.Topic.Id, Id, Title, Body, CreatedAt);
    }
}
