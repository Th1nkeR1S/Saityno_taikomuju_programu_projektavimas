using Microsoft.AspNetCore.Identity;

namespace KasisAPI.Auth.Model
{
    public class ForumUser : IdentityUser
    {
        
    }
}
