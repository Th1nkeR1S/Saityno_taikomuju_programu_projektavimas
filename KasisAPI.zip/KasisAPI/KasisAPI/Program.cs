using System;
using KasisAPI.Data;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SharpGrip.FluentValidation.AutoValidation.Endpoints.Extensions;
using SharpGrip.FluentValidation.AutoValidation.Endpoints.Results;
using SharpGrip.FluentValidation.AutoValidation.Shared.Extensions;

public class ProblemDetailsResultFactory : IFluentValidationAutoValidationResultFactory
{
    public IResult CreateResult(EndpointFilterInvocationContext context, ValidationResult validationResult)
    {
        var problemDetails = new HttpValidationProblemDetails(validationResult.ToValidationProblemErrors())
        {
            Type =  "https://tools.ietf.org/html/rfc4918#section-11.2",
            Title = "Unprocessable Entity",
            Status = 422
        };

        return Results.Problem(problemDetails);
    }
}

public record TopicDto(int Id, string Title, string Description, DateTimeOffset CreatedAt);

public record CreateOrUpdateTopicDto(string Title, string Description)
{
    public class CreateOrUpdateTopicDtoValidator : AbstractValidator<CreateOrUpdateTopicDto>
    {
        public CreateOrUpdateTopicDtoValidator()
        {
            RuleFor(x => x.Title).NotEmpty().Length(min:1, max:100);
            RuleFor(x => x.Description).NotEmpty().Length(min:1, max:1000);
        }
    }
}

public record PostDto(int TopicId, int Id, string Title, string Body, DateTimeOffset CreatedAt);

public record CreateOrUpdatePostDto(int TopicId, string Title, string Body)
{
    public class CreateOrUpdatePostDtoValidator : AbstractValidator<CreateOrUpdatePostDto>
    {
        public CreateOrUpdatePostDtoValidator()
        {
            RuleFor(x => x.Title).NotEmpty().Length(min:1, max:100);
            RuleFor(x => x.Body).NotEmpty().Length(min:1, max:10000);
        }
    }
}

public record CommentDto(int PostId, int Id, string Content, DateTimeOffset CreatedAt);

public record CreateOrUpdateCommentDto(int PostId, string Content)
{
    public class CreateOrUpdateCommentDtoValidator : AbstractValidator<CreateOrUpdateCommentDto>
    {
        public CreateOrUpdateCommentDtoValidator()
        {
            RuleFor(x => x.Content).NotEmpty().Length(min:1, max:10000);
        }
    }
}

public class Program
{
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        builder.Services.AddDbContext<KasisDbContext>();
        builder.Services.AddValidatorsFromAssemblyContaining<Program>();
        builder.Services.AddFluentValidationAutoValidation(configuration =>
        {
            configuration.OverrideDefaultResultFactoryWith<ProblemDetailsResultFactory>();
        });

        var app = builder.Build();

        app.AddTopicsApi();
        app.AddPostsApi();
        app.AddCommentsApi();

        app.Run();
    }
}
